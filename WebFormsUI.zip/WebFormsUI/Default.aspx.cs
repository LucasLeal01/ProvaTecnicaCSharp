using System;
using System.Web.UI;

namespace WebFormsUI
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}

